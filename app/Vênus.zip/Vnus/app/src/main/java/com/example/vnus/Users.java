package com.example.vnus;

public class Users {

    private String id;
    private String email;
    private String senha;
    private String nome;
    private String sobrenome;

    public Users(){

    }

    public Users(String id, String nome, String sobrenome, String email, String senha){
        this.id=id;
        this.nome=nome;
        this.sobrenome=sobrenome;
        this.email=email;
        this.senha=senha;
    }

    public String getId(){
        return id;
    }
    public void setId(String id){
        this.id=id;
    }

    public String nome(){
        return nome;
    }
    public void setNome(String nome){
        this.nome=nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }
    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public String getSenha() {
        return senha;
    }
    public void setSenha(String senha){
        this.senha = senha;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(){
        this.email=email;
    }
}
