package com.example.vnus;

public class Usuaria extends Users{

    public Usuaria(){

    }

    public Usuaria(String id, String nome, String sobrenome, String email, String senha){
        super(id, nome, sobrenome, email, senha);
    }
}
