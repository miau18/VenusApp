package com.example.vnus;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;

public class UserRepository {
    private final FirebaseFirestore db;

    public UserRepository(){
        db = FirebaseFirestore.getInstance();
    }

    public void saveUser(Users user, OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener){
        db.collection("users").document(user.getId()).set(user).addOnSuccessListener(onSuccessListener).addOnFailureListener(onFailureListener);
    }
}
