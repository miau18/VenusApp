package com.example.vnus;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth auth;
    private UserRepository userRepository;
    private PsicologoRepository psicologoRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        auth = FirebaseAuth.getInstance();
        userRepository = new UserRepository();
        psicologoRepository = new PsicologoRepository();

        EditText nameEditText = findViewById(R.id.editTextName);
        EditText sobrenomeEditText = findViewById(R.id.editTextSobrenome);
        EditText emailEditText = findViewById(R.id.editTextEmail);
        EditText crpEditText = findViewById(R.id.editTextCrp);
        EditText passwordEditText = findViewById(R.id.editTextSenha);
        Button registerButton = findViewById(R.id.buttonRegister);

        registerButton.setOnClickListener(view -> {
            String name = nameEditText.getText().toString();
            String sobrenome = sobrenomeEditText.getText().toString();
            String email = emailEditText.getText().toString();
            String crp = crpEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            // Validação dos campos
            if (name.isEmpty() || sobrenome.isEmpty() || email.isEmpty() || crp.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Criação do usuário no Firebase Authentication
            auth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, task -> {
                        if (task.isSuccessful()) {
                            FirebaseUser firebaseUser = auth.getCurrentUser();
                            if (firebaseUser != null) {
                                String userId = firebaseUser.getUid();

                                // Salvar dados comuns do usuário (Users) no Firestore
                                Users user = new Users(userId, email, name, sobrenome, password); // Incluindo a senha aqui
                                userRepository.saveUser(user,
                                        aVoid -> {
                                            // Se o usuário for salvo com sucesso, salvar dados específicos do psicólogo
                                            Psicologo psicologo = new Psicologo(userId, email, name, sobrenome, password, crp); // Incluindo a senha aqui
                                            psicologoRepository.savePsicologoSpecificData(userId, psicologo,
                                                    aVoid1 -> Toast.makeText(MainActivity.this, "Psicólogo registrado com sucesso!", Toast.LENGTH_SHORT).show(),
                                                    e -> Toast.makeText(MainActivity.this, "Erro ao salvar dados do psicólogo: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                                            );
                                        },
                                        e -> Toast.makeText(MainActivity.this, "Erro ao salvar dados do usuário: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                                );
                            } else {
                                Toast.makeText(MainActivity.this, "Erro: Usuário Firebase nulo após registro.", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            // Erro no registro do Firebase Authentication
                            Toast.makeText(MainActivity.this, "Erro no registro: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        });
    }
}