package com.example.vnus;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;

public class PsicologoRepository {
    private final FirebaseFirestore db;
    public PsicologoRepository() {
        db = FirebaseFirestore.getInstance();
    }

    public void savePsicologoSpecificData(String userId, Psicologo psicologo, OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {
        db.collection("psicologos").document(userId)
                .set(psicologo)
                .addOnSuccessListener(onSuccessListener)
                .addOnFailureListener(onFailureListener);
    }
}
